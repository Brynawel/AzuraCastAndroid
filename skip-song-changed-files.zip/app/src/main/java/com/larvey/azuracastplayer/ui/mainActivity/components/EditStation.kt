package com.larvey.azuracastplayer.ui.mainActivity.components

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.input.TextFieldLineLimits
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.foundation.text.input.setTextAndPlaceCursorAtEnd
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.larvey.azuracastplayer.classes.data.SavedStation
import com.larvey.azuracastplayer.classes.data.StationJSON
import com.larvey.azuracastplayer.db.settings.SettingsViewModel
import com.larvey.azuracastplayer.db.settings.SettingsViewModel.SettingsModelProvider
import com.larvey.azuracastplayer.db.settings.apiKeyId
import com.larvey.azuracastplayer.utils.fixHttps
import com.larvey.azuracastplayer.utils.supportedMounts

private const val TAG = "EditStation"

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditStation(
  hideDialog: () -> Unit, station: SavedStation, stationData: StationJSON?,
  editStation: (SavedStation) -> Unit
) {
  val context = LocalContext.current
  if (stationData == null) {
    Toast.makeText(
      context,
      "Cannot access station API",
      Toast.LENGTH_LONG
    ).show()
    hideDialog()
    return
  }
  var stationFieldRename by remember { mutableStateOf(station.name) }
  var expandedDropdown by remember { mutableStateOf(false) }
  val mounts = stationData.station.mounts
  val hls = stationData.station.hlsEnabled
  var setMount by remember { mutableStateOf(station.defaultMount) }

  // Optional AzuraCast API key (enables the Skip button). Stored in DataStore, not Room.
  val settingsModel: SettingsViewModel = viewModel(factory = SettingsModelProvider.Factory)
  val savedApiKeys by settingsModel.apiKeys.collectAsState()
  val savedApiKey = savedApiKeys[apiKeyId(
    station.url,
    station.shortcode
  )]
  var apiKeyField by remember(savedApiKey) { mutableStateOf(savedApiKey ?: "") }

  val defaultMount = stationData.station.mounts.find {
    it.url == station.defaultMount
  } ?: stationData.station.mounts.supportedMounts()
    .first() // Known sharp edge: throws if a station serves no supported mounts.

  val textFieldState =
    rememberTextFieldState(
      if (station.defaultMount.endsWith(".m3u8"))
        "HLS (experimental)"
      else
        defaultMount.name
    )

  Dialog(onDismissRequest = { hideDialog() }) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "Edit Station",
          style = MaterialTheme.typography.titleLarge
        )
        OutlinedTextField(
          modifier = Modifier.padding(top = 16.dp),
          value = stationFieldRename,
          onValueChange = {
            stationFieldRename = it
          },
          singleLine = true,
          label = { Text("Station Name") },
          placeholder = { Text(stationData.station.name) }
        )
        ExposedDropdownMenuBox(
          modifier = Modifier.padding(top = 8.dp),
          expanded = expandedDropdown,
          onExpandedChange = { expandedDropdown = it }
        ) {
          OutlinedTextField(
            modifier = Modifier.menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable),
            state = textFieldState,
            readOnly = true,
            lineLimits = TextFieldLineLimits.SingleLine,
            label = { Text("Default Mount") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
            colors = ExposedDropdownMenuDefaults.textFieldColors(),
          )
          ExposedDropdownMenu(
            expanded = expandedDropdown,
            onDismissRequest = { expandedDropdown = false }
          ) {
            mounts.supportedMounts().forEach { mount ->
              DropdownMenuItem(
                text = {
                  Text(
                    mount.name,
                    style = MaterialTheme.typography.bodyLarge
                  )
                },
                onClick = {
                  textFieldState.setTextAndPlaceCursorAtEnd(mount.name)
                  setMount = mount.url.fixHttps()
                  expandedDropdown = false
                },
                contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
              )
            }
            if (hls) {
              DropdownMenuItem(
                text = {
                  Text(
                    "HLS (experimental)",
                    style = MaterialTheme.typography.bodyLarge
                  )
                },
                onClick = {
                  textFieldState.setTextAndPlaceCursorAtEnd("HLS (experimental)")
                  setMount = stationData.station.hlsUrl!!.fixHttps()
                  expandedDropdown = false
                },
                contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding
              )
            }
          }
        }
        OutlinedTextField(
          modifier = Modifier.padding(top = 8.dp),
          value = apiKeyField,
          onValueChange = { apiKeyField = it },
          singleLine = true,
          visualTransformation = PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
          label = { Text("API Key (optional)") },
          supportingText = {
            Text("Adds a Skip button. Needs the \"Manage Station Broadcasting\" permission.")
          }
        )
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
          horizontalArrangement = Arrangement.End
        ) {
          TextButton(onClick = {
            hideDialog()
          }) {
            Text("Cancel")
          }
          TextButton(
            onClick = {

              val newStation = SavedStation(
                name = stationFieldRename,
                url = station.url,
                shortcode = station.shortcode,
                defaultMount = setMount,
                position = station.position
              )
              Log.d(
                TAG,
                "Saving edited station: $newStation"
              )
              settingsModel.setApiKey(
                station.url,
                station.shortcode,
                apiKeyField
              )
              editStation(
                newStation
              )
              hideDialog()
            },
            enabled = stationFieldRename.isNotEmpty()
          ) {
            Text("Save")
          }
        }
      }
    }
  }

}