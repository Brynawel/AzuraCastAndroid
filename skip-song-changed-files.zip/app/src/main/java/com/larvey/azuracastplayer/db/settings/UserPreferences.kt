package com.larvey.azuracastplayer.db.settings

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

const val IS_GRID_VIEW = "is_grid_view"
const val THEME_TYPE = "theme_type"
const val IS_DYNAMIC_THEME = "is_dynamic_theme"
const val ANDROID_AUTO_LAYOUT = "android_auto_layout"
const val LEGACY_MEDIA_BACKGROUND = "legacy_media_background"

/** DataStore key prefix for per-station AzuraCast API keys (see [apiKeyId]). */
const val API_KEY_PREFIX = "api_key:"

/** Identifies a saved station in the API-key map: `<host>|<shortcode>`. */
fun apiKeyId(url: String, shortCode: String): String = "$url|$shortCode"

enum class ThemeTypes { SYSTEM, LIGHT, DARK }

enum class AndroidAutoLayouts { GRID, LIST }

class UserPreferences(private val dataStore: DataStore<Preferences>) {
  companion object {
    val isGridView = booleanPreferencesKey(IS_GRID_VIEW)
    val themeType = intPreferencesKey(THEME_TYPE)
    val isDynamicTheme = booleanPreferencesKey(IS_DYNAMIC_THEME)
    val androidAutoLayout = intPreferencesKey(ANDROID_AUTO_LAYOUT)
    val legacyMediaBackground = booleanPreferencesKey(LEGACY_MEDIA_BACKGROUND)
  }

  val isGridViewFlow: Flow<Boolean> = dataStore.data.map { preferences ->
    preferences[isGridView] != false
  }

  val isDynamicThemeFlow: Flow<Boolean> = dataStore.data.map { preferences ->
    preferences[isDynamicTheme] != false
  }

  val themeTypeFlow: Flow<ThemeTypes> = dataStore.data.map { preferences ->
    ThemeTypes.entries[preferences[themeType] ?: 0]
  }

  val androidAutoLayoutFlow: Flow<AndroidAutoLayouts> = dataStore.data.map { preferences ->
    AndroidAutoLayouts.entries[preferences[androidAutoLayout] ?: 0]
  }

  val legacyMediaBackgroundFlow: Flow<Boolean> = dataStore.data.map { preferences ->
    preferences[legacyMediaBackground] == true
  }

  /**
   * Per-station AzuraCast API keys (optional; enables the Skip button), keyed
   * by [apiKeyId]. Kept in DataStore rather than the Room `SavedStation` table
   * so no schema bump (and therefore no destructive migration) is needed.
   */
  val apiKeysFlow: Flow<Map<String, String>> = dataStore.data.map { preferences ->
    preferences.asMap().mapNotNull { (key, value) ->
      if (key.name.startsWith(API_KEY_PREFIX) && value is String) {
        key.name.removePrefix(API_KEY_PREFIX) to value
      } else {
        null
      }
    }.toMap()
  }

  /** Saves (or, when [apiKey] is blank, removes) the API key for one station. */
  fun setApiKey(url: String, shortCode: String, apiKey: String, scope: CoroutineScope) {
    val key = stringPreferencesKey(API_KEY_PREFIX + apiKeyId(url, shortCode))
    scope.launch {
      dataStore.edit { preferences ->
        if (apiKey.isBlank()) {
          preferences.remove(key)
        } else {
          preferences[key] = apiKey.trim()
        }
      }
    }
  }

  fun setGridView(value: Boolean, scope: CoroutineScope) {
    scope.launch {
      dataStore.edit { preferences ->
        preferences[isGridView] = value
      }
    }
  }

  fun setDynamicTheme(value: Boolean, scope: CoroutineScope) {
    scope.launch {
      dataStore.edit { preferences ->
        preferences[isDynamicTheme] = value
      }
    }
  }

  fun setThemeType(value: ThemeTypes, scope: CoroutineScope) {
    scope.launch {
      dataStore.edit { preferences ->
        preferences[themeType] = value.ordinal
      }
    }
  }

  fun setAndroidAutoLayout(value: AndroidAutoLayouts, scope: CoroutineScope) {
    scope.launch {
      dataStore.edit { preferences ->
        preferences[androidAutoLayout] = value.ordinal
      }
    }
  }

  fun setLegacyMediaBackground(value: Boolean, scope: CoroutineScope) {
    scope.launch {
      dataStore.edit { preferences ->
        preferences[legacyMediaBackground] = value
      }
    }
  }

}