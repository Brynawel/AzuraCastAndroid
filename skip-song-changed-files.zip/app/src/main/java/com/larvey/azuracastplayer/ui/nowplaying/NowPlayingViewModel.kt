package com.larvey.azuracastplayer.ui.nowplaying

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.larvey.azuracastplayer.api.ApiResult
import com.larvey.azuracastplayer.api.AzuraCastRepository
import com.larvey.azuracastplayer.classes.models.CastManager
import com.larvey.azuracastplayer.classes.models.NowPlayingData
import com.larvey.azuracastplayer.classes.models.SavedStationsDB
import com.larvey.azuracastplayer.classes.models.SharedMediaController
import com.larvey.azuracastplayer.session.cast.CastConnectivity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val TAG = "NowPlayingViewModel"

/** Gives AzuraCast a moment to start the next song before re-fetching metadata. */
private const val SKIP_REFRESH_DELAY_MS = 1_500L

@HiltViewModel
class NowPlayingViewModel @Inject constructor(
  val nowPlayingData: NowPlayingData,
  val savedStationsDB: SavedStationsDB,
  val sharedMediaController: SharedMediaController,
  val castManager: CastManager,
  val castConnectivity: CastConnectivity,
  private val repository: AzuraCastRepository
) : ViewModel() {

  private var skipInFlight = false

  /**
   * Skips the song playing on the active station using [apiKey], then
   * refreshes the now-playing metadata. Affects every listener of the
   * station. [onFailure] receives a short user-facing message. Ignored while
   * a previous skip is still in flight.
   */
  fun skipSong(apiKey: String, onFailure: (String) -> Unit) {
    if (skipInFlight) return
    val url = nowPlayingData.nowPlayingURL.value
    val shortCode = nowPlayingData.nowPlayingShortCode.value
    if (url.isBlank() || shortCode.isBlank()) return

    skipInFlight = true
    viewModelScope.launch {
      try {
        when (val result = repository.skipSong(
          url,
          shortCode,
          apiKey
        )) {
          is ApiResult.Success -> {
            Log.i(
              TAG,
              "Skipped song on $shortCode@$url"
            )
            delay(SKIP_REFRESH_DELAY_MS)
            nowPlayingData.setMediaMetadata(
              url = url,
              shortCode = shortCode,
              mediaPlayer = sharedMediaController.mediaSession.value?.player
            )
          }

          is ApiResult.Failure -> {
            Log.e(
              TAG,
              "Failed to skip song on $shortCode@$url: $result"
            )
            onFailure(skipFailureMessage(result))
          }
        }
      } finally {
        skipInFlight = false
      }
    }
  }

  private fun skipFailureMessage(failure: ApiResult.Failure): String = when (failure) {
    is ApiResult.Failure.Http -> when (failure.code) {
      401, 403 -> "Skip failed: API key rejected or missing permission"
      404 -> "Skip failed: station not found"
      else -> "Skip failed (HTTP ${failure.code})"
    }

    is ApiResult.Failure.Network -> "Skip failed: couldn't reach the server"
    is ApiResult.Failure.Unexpected -> "Skip failed: unexpected error"
  }
}
