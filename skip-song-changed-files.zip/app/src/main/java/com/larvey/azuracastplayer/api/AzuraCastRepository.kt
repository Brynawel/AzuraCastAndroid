package com.larvey.azuracastplayer.api

import androidx.annotation.VisibleForTesting
import com.larvey.azuracastplayer.classes.data.DiscoveryJSON
import com.larvey.azuracastplayer.classes.data.Song
import com.larvey.azuracastplayer.classes.data.StationJSON
import com.larvey.azuracastplayer.rewriteHost
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The app's single gateway to the network. Wraps [AzuraCastApi] and maps every
 * call into a typed [ApiResult] so callers handle failures explicitly.
 *
 * Threading: safe to call from any dispatcher, **including the main thread**.
 * Retrofit suspend functions are non-blocking (they enqueue internally and
 * resume on the caller's dispatcher), so this class deliberately does NOT
 * switch to [kotlinx.coroutines.Dispatchers.IO]. Do not "add IO for safety" —
 * callers such as [com.larvey.azuracastplayer.classes.models.NowPlayingData]
 * rely on resuming on the main thread to mutate the Media3 player, which must
 * only be touched from its application thread.
 *
 * Logging: this class intentionally does not log. It returns typed failures;
 * callers log with the context only they have (station short code, host, …).
 */
@Singleton
class AzuraCastRepository @Inject constructor(
  private val api: AzuraCastApi
) {

  /** Fetches one station's now-playing metadata (primary metadata source). */
  suspend fun getNowPlayingData(
    host: String,
    shortCode: String
  ): ApiResult<StationJSON> {
    val result = safeApiCall {
      api.getNowPlayingData(
        nowPlayingUrl(
          host,
          shortCode
        )
      )
    }
    return when (result) {
      // Artwork links are pointed at the website host (see HOST_REWRITES).
      is ApiResult.Success -> ApiResult.Success(
        runCatching { result.data.withRewrittenArt() }.getOrDefault(result.data)
      )

      is ApiResult.Failure -> result
    }
  }

  /** Lists every station served by [host] (add-station search). */
  suspend fun listHostStations(host: String): ApiResult<List<StationJSON>> = safeApiCall {
    api.listNowPlaying(nowPlayingUrl(host))
  }

  /**
   * Skips the song currently playing on [shortCode]. Affects every listener of
   * the station. [apiKey] needs the "Manage Station Broadcasting" permission.
   */
  suspend fun skipSong(
    host: String,
    shortCode: String,
    apiKey: String
  ): ApiResult<Unit> = safeApiCall {
    api.skipSong(
      skipUrl(
        host,
        shortCode
      ),
      apiKey
    )
  }

  /** Fetches the community discovery catalog. */
  suspend fun getDiscoveryCatalog(): ApiResult<DiscoveryJSON> = safeApiCall {
    api.getDiscoveryCatalog()
  }

  private fun Song.withRewrittenArt(): Song = copy(art = art.rewriteHost())

  private fun StationJSON.withRewrittenArt(): StationJSON = copy(
    nowPlaying = nowPlaying.copy(song = nowPlaying.song.withRewrittenArt()),
    playingNext = playingNext?.let { it.copy(song = it.song.withRewrittenArt()) },
    songHistory = songHistory.map { it.copy(song = it.song.withRewrittenArt()) }
  )

  companion object {

    /**
     * URL builders are pure and kept visible for tests. [host] may include a
     * port (e.g. "radio.example.com:8080") and is always addressed over HTTPS,
     * matching the app-wide `fixHttps` convention. The two overloads build the
     * single-station now-playing URL and the host-wide station-list URL.
     */
    // This fork reads the cached static file (what the Play-store release used)
    // instead of the live /api/nowplaying/{shortCode} endpoint: on this server the
    // live endpoint hands back album-art links that don't load, the static file's do.
    @VisibleForTesting
    internal fun nowPlayingUrl(host: String, shortCode: String): String =
      "https://$host/api/nowplaying_static/$shortCode.json"

    @VisibleForTesting
    internal fun nowPlayingUrl(host: String): String = "https://$host/api/nowplaying"

    /** URL of the AzuraCast "skip current song" endpoint for one station. */
    @VisibleForTesting
    internal fun skipUrl(host: String, shortCode: String): String =
      "https://$host/api/station/$shortCode/backend/skip"
  }
}
