package com.larvey.azuracastplayer

/**
 * A station that is always present in this build. [host] is the bare AzuraCast
 * website host (no https://) used for artwork, track info and skipping.
 * The station's name and stream are normally read from the server the first
 * time (exactly as the "add station" screen does); [name] and
 * [fallbackStreamUrl] are only used if the server can't be reached then.
 */
data class LockedStation(
  val name: String,
  val host: String,
  val shortcode: String,
  val fallbackStreamUrl: String
)

/** When false the Add button and the Discover tab are hidden (this build is for one owner's stations). */
val ALLOW_ADD_STATIONS = false

/**
 * The stations this build ships with. Any that are missing are re-added on
 * launch; renaming, reordering or choosing another mount in the app is kept.
 * To add a station later, add another entry here and rebuild.
 */
val LOCKED_STATIONS = listOf(
  LockedStation(
    name = "Power Hit Radio",
    host = "radio.powerhitradio.co.uk",
    shortcode = "powerhitradio",
    fallbackStreamUrl = "https://stream.powerhitradio.co.uk/listen/powerhitradio/stream64"
  ),
  LockedStation(
    name = "Power Hit Radio 80's",
    host = "radio.powerhitradio.co.uk",
    shortcode = "powerhitradio_80s",
    fallbackStreamUrl = "https://stream.powerhitradio.co.uk/listen/powerhitradio_80s/radio.mp3"
  )
)
