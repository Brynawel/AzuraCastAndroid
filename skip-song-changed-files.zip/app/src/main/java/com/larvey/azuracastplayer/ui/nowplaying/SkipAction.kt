package com.larvey.azuracastplayer.ui.nowplaying

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.larvey.azuracastplayer.db.settings.SettingsViewModel
import com.larvey.azuracastplayer.db.settings.SettingsViewModel.SettingsModelProvider
import com.larvey.azuracastplayer.db.settings.apiKeyId

/**
 * Returns the "skip song" action for the station that is currently playing, or
 * null when that station has no API key saved (in which case the Skip button
 * is hidden). Recomposes when the playing station or its saved key changes.
 */
@Composable
fun skipActionOrNull(nowPlayingViewModel: NowPlayingViewModel): (() -> Unit)? {
  val context = LocalContext.current
  val settingsModel: SettingsViewModel = viewModel(factory = SettingsModelProvider.Factory)
  val apiKeys by settingsModel.apiKeys.collectAsState()

  val nowPlayingData = nowPlayingViewModel.nowPlayingData
  val apiKey = apiKeys[apiKeyId(
    nowPlayingData.nowPlayingURL.value,
    nowPlayingData.nowPlayingShortCode.value
  )]
  if (apiKey.isNullOrBlank()) return null

  return {
    nowPlayingViewModel.skipSong(apiKey) { message ->
      Toast.makeText(
        context,
        message,
        Toast.LENGTH_LONG
      ).show()
    }
  }
}
