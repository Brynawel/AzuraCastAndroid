package com.larvey.azuracastplayer

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.larvey.azuracastplayer.classes.data.SavedStation
import com.larvey.azuracastplayer.classes.models.NowPlayingData
import com.larvey.azuracastplayer.classes.models.SavedStationsDB
import com.larvey.azuracastplayer.db.settings.UserPreferences
import com.larvey.azuracastplayer.session.sleepTimer.AndroidAlarmScheduler
import com.larvey.azuracastplayer.session.sleepTimer.SleepItem
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.android.HiltAndroidApp
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDateTime

val Context.dataStore by preferencesDataStore("settings")

/**
 * Application entry point. Boots Hilt, cancels any sleep alarm left over from
 * a previous process, warms the station metadata cache for every saved
 * station, and holds the app-wide [UserPreferences] instance (created here
 * rather than via Hilt so the DataStore delegate lives on the Application).
 */
@HiltAndroidApp
class AppSetup : Application() {
  lateinit var userPreferences: UserPreferences

  override fun onCreate() {
    super.onCreate()
    val scheduler = AndroidAlarmScheduler(this)
    SleepItem(LocalDateTime.now()).let(scheduler::cancel)
    getInitialStations()
    userPreferences = UserPreferences(dataStore)
  }

  private fun getInitialStations() {
    val savedStationEntryPoint = EntryPointAccessors.fromApplication(
      this,
      SavedStationsDBEntryPoint::class.java
    )
    val nowPlayingDataEntryPoint = EntryPointAccessors.fromApplication(
      this,
      NowPlayingDataEntryPoint::class.java
    )
    val savedStationsDB = savedStationEntryPoint.savedStationsDB
    val nowPlayingData = nowPlayingDataEntryPoint.nowPlayingData
    CoroutineScope(Dispatchers.IO).launch {
      ensureLockedStations(savedStationsDB)
      val stations = savedStationsDB.getAllEntries()
      savedStationsDB.savedStations.value = stations
      for (item in stations) {
        nowPlayingData.getStationInformation(
          url = item.url,
          shortCode = item.shortcode
        )
      }
    }
  }


  /** Adds any [LOCKED_STATIONS] that are missing from the database (existing ones are left alone). */
  private suspend fun ensureLockedStations(savedStationsDB: SavedStationsDB) {
    val existing = savedStationsDB.getAllEntries()
    var nextPosition = (existing.maxOfOrNull { it.position } ?: -1) + 1
    for (station in LOCKED_STATIONS) {
      val present = existing.any {
        it.url == station.host && it.shortcode == station.shortcode
      }
      if (!present) {
        savedStationsDB.saveStation(
          SavedStation(
            name = station.name,
            url = station.host,
            shortcode = station.shortcode,
            defaultMount = station.streamUrl,
            position = nextPosition++
          )
        )
      }
    }
  }

  @EntryPoint
  @InstallIn(SingletonComponent::class)
  interface SavedStationsDBEntryPoint {
    val savedStationsDB: SavedStationsDB
  }

  @EntryPoint
  @InstallIn(SingletonComponent::class)
  interface NowPlayingDataEntryPoint {
    val nowPlayingData: NowPlayingData
  }
}